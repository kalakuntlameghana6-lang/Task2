# Task 1: Data Cleaning and Preprocessing

## Objective
Clean a raw dataset containing missing values, duplicate records, inconsistent text, date formats, and incorrect data types.

## Tools
- Python 3
- pandas

## Project structure
```text
data_cleaning_preprocessing_task/
├── data/
│   ├── raw/sample_sales.csv
│   └── cleaned/cleaned_sales.csv       # generated after running the script
├── reports/
│   └── cleaning_summary.txt            # generated after running the script
├── src/
│   └── clean_data.py
├── requirements.txt
└── README.md
```

## Setup in VS Code
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. (Recommended) Create and activate a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
5. Install the dependency: `pip install -r requirements.txt`
6. Run: `python src/clean_data.py`

## What the script does
- Renames column headers to lowercase names with underscores.
- Removes exact duplicate rows.
- Removes extra spaces from text values.
- Standardizes gender and country values.
- Converts age and amount to numeric data types.
- Converts order_date to datetime; invalid dates become missing (`NaT`).
- Fills missing numeric values with the median.
- Fills missing text values with `Unknown`.
- Saves the cleaned CSV and a summary report.

## Use your own Kaggle dataset
Download a CSV dataset from Kaggle and place it in `data/raw/`. Update `INPUT_FILE` in `src/clean_data.py` to the new filename. If your dataset has different columns, adjust the column-specific cleaning rules (`gender`, `country`, `age`, `amount`, and `order_date`) to match its actual column names.

## Important notes
- Median imputation is a simple demonstration; choose an appropriate method based on the meaning and distribution of each column.
- Invalid dates are left missing instead of being guessed.
- Keep an untouched copy of the original dataset in `data/raw/`.
- Do not upload private or personally identifiable data to a public GitHub repository.

## GitHub submission checklist
- [ ] Upload the source code.
- [ ] Include the dataset only if its license permits redistribution and it contains no private data.
- [ ] Include the cleaning summary.
- [ ] Add screenshots of the program output if requested.
- [ ] Explain the cleaning steps in this README.
