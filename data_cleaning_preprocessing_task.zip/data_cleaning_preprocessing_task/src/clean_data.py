"""
Data Cleaning and Preprocessing
Run from this folder:
    python src/clean_data.py
The script reads data/raw/sample_sales.csv and creates:
    data/cleaned/cleaned_sales.csv
    reports/cleaning_summary.txt
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = ROOT / "data" / "raw" / "sample_sales.csv"
OUTPUT_DIR = ROOT / "data" / "cleaned"
REPORT_DIR = ROOT / "reports"

def clean_column_names(df):
    df.columns = (
        df.columns.astype(str)
        .str.strip()
        .str.lower()
        .str.replace(r"[^a-z0-9]+", "_", regex=True)
        .str.strip("_")
    )
    return df

def clean_dataset(df):
    original_rows = len(df)
    original_missing = int(df.isna().sum().sum())

    df = clean_column_names(df)
    df = df.drop_duplicates()
    duplicates_removed = original_rows - len(df)

    # Standardize text values.
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype("string").str.strip()

    if "gender" in df.columns:
        gender_map = {
            "m": "Male", "male": "Male",
            "f": "Female", "female": "Female"
        }
        df["gender"] = df["gender"].str.lower().map(gender_map).fillna(df["gender"])

    if "country" in df.columns:
        df["country"] = df["country"].str.upper()

    # Convert numeric fields; invalid values become missing values.
    for col in ("age", "amount"):
        if col in df.columns:
            cleaned = df[col].astype("string").str.replace(",", "", regex=False)
            df[col] = pd.to_numeric(cleaned, errors="coerce")

    # Convert dates to pandas datetime. Invalid dates become NaT.
    if "order_date" in df.columns:
        df["order_date"] = pd.to_datetime(
            df["order_date"], errors="coerce", dayfirst=True
        )

    # Fill numeric missing values with the column median.
    for col in df.select_dtypes(include="number").columns:
        if df[col].isna().any():
            median_value = df[col].median()
            if pd.notna(median_value):
                df[col] = df[col].fillna(median_value)

    # Fill missing text values with a clear label.
    for col in df.select_dtypes(include=["object", "string"]).columns:
        df[col] = df[col].fillna("Unknown")

    # Keep invalid/missing dates as NaT; do not invent dates.
    final_missing = int(df.isna().sum().sum())
    summary = {
        "rows_before": original_rows,
        "rows_after": len(df),
        "duplicates_removed": duplicates_removed,
        "missing_cells_before": original_missing,
        "missing_cells_after": final_missing,
        "columns": list(df.columns),
        "data_types": {col: str(dtype) for col, dtype in df.dtypes.items()},
    }
    return df, summary

def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Input dataset not found: {INPUT_FILE}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    raw_df = pd.read_csv(INPUT_FILE)
    cleaned_df, summary = clean_dataset(raw_df)

    output_file = OUTPUT_DIR / "cleaned_sales.csv"
    report_file = REPORT_DIR / "cleaning_summary.txt"

    cleaned_df.to_csv(output_file, index=False)
    with report_file.open("w", encoding="utf-8") as f:
        f.write("DATA CLEANING SUMMARY\n")
        f.write("=====================\n")
        for key, value in summary.items():
            f.write(f"{key}: {value}\n")

    print("Data cleaning completed successfully.")
    print(f"Cleaned dataset: {output_file}")
    print(f"Summary report: {report_file}")
    print(f"Rows before: {summary['rows_before']}")
    print(f"Rows after: {summary['rows_after']}")
    print(f"Duplicates removed: {summary['duplicates_removed']}")

if __name__ == "__main__":
    main()
